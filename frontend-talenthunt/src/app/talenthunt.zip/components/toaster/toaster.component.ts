import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-toaster',
  templateUrl: './toaster.component.html',
  styleUrls: ['./toaster.component.css']
})
export class ToasterComponent implements OnInit {

  constructor(private toastr: ToastrService) {
    
   }
  showSuccess() {
    this.toastr.success('Successfully added!', 'Welcome!');
  }
  showSuccess1() {
    this.toastr.error('Successfully added!', 'Welcome!');
  }
  showSuccess2() {
    this.toastr.info('Successfully added!', 'Welcome!');
  }
  
  

  ngOnInit(): void {
  }

}
